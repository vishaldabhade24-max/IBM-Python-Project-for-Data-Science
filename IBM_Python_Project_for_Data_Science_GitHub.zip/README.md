# IBM Python Project for Data Science

This repository contains six Jupyter notebooks for the IBM Python Project for Data Science assignment.

## Notebooks

1. `Question_1_Tesla_Stock_Data.ipynb` — Extract Tesla stock data using yfinance.
2. `Question_2_Tesla_Revenue_Webscraping.ipynb` — Scrape Tesla revenue data.
3. `Question_3_GameStop_Stock_Data.ipynb` — Extract GameStop stock data using yfinance.
4. `Question_4_GameStop_Revenue_Webscraping.ipynb` — Scrape GameStop revenue data.
5. `Question_5_Tesla_Stock_Graph.ipynb` — Visualize Tesla stock price and revenue.
6. `Question_6_GameStop_Stock_Graph.ipynb` — Visualize GameStop stock price and revenue.

## How to run

Open the notebooks in Jupyter Notebook or Google Colab and run the cells from top to bottom. Some cells require an internet connection to retrieve stock and revenue data.

## Notes

This repository is a learning assignment. Review the notebook outputs and capture any screenshots required by your course before submitting.
